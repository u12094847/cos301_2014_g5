#undef PACKAGE
#undef VERSION
